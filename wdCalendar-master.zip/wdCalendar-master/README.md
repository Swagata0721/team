wdCalendar
==========

wdCalendar is a jquery based google calendar clone. Based on http://www.web-delicious.com/jquery-plugins-demo/wdCalendar/docs/index.htm

1. Introduction
This is wdCalendar version2 and allowed to use freely (LGPL).

2. Browsers Supported
FireFox2.0+ IE6+ Opera9+ Safari3+ Chrome

3. Installation & Usage
Download the package and unzip to a directory.
Copy unzipped directory to apache www directory/sub-directory.
Open sample.php in your browser.
-----------------------IMPORTANT!!!IMPORTANT!!!-----------------
By default, events are created randomly. If you would like it work with database, please
a. create a database, and execute setup.sql
b. change php/dbconfig.php to fit yours
c. rename edit.db.php to edit.php, php/datafeed.db.php to php/datafeed.php (you may backup edit.php/datafeed.php)

4. About web-delicious.com
We are an IT outsourcing company location in Shanghai, China.
We provide end-to-end solutions in web development (Web 2.0, PHP, ASP.NET, ASP, JSP, XML, Flash),
application development and IT consulting services at very reasonable price.
www.web-delicious.com


5.Credits
jQuery is a new kind of JavaScript Library. http://jquery.com/
wdCalendar Library. base script from http://www.web-delicious.com

